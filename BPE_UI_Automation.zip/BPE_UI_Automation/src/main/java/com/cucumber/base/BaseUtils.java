package com.cucumber.base;

import org.openqa.selenium.WebDriver;

public class BaseUtils {

    public WebDriver driver;
    public String browser;
}
