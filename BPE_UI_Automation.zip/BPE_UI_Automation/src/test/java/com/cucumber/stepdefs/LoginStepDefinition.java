package com.cucumber.stepdefs;

import com.browser.capabilities.LaunchBrowser;
import com.cucumber.base.BaseUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import java.util.concurrent.TimeUnit;

import org.jsoup.Connection;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginStepDefinition extends BaseUtils {

    private BaseUtils base;

    public LoginStepDefinition(BaseUtils base){
        this.base = base;
    }

    @Given("I launch application using url '(.*)'")
    public void iLaunchApplication(String url) throws Throwable {

        base.driver.get(url);
        Thread.sleep(1000);
      }

    @And("^user enter the username and password$")
    public void userEnterTheUsernameAndPassword() {
    	base.driver.findElement(By.xpath("/html/body/div/div/form[2]/input[1]")).sendKeys("bpeadmin");
		base.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		base.driver.findElement(By.xpath("/html/body/div/div/form[2]/input[2]")).sendKeys("pwd");
		base.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		base.driver.findElement(By.xpath("/html/body/div/div/form[2]/button[1]")).click();
    }
       @And("^Admin HomePage is loaded$")
       @Then("^user verify the Homepage page is loaded$")
    public void userVerifyHomepagePageIsLoaded() {
    	 if (base.driver.findElement(By.xpath("/html/body/app-root/div/uitk-header/header/img")).isDisplayed()) {
    		   System.out.println("Passed, Home Page opens");
    				}
    		   else {
    			System.out.println("Failed, Home Page does not open");
    		  }
    }
       
       @And("^user clicks on LogOut button$")
       public void click_on_LogOut_Button() {
    	   base.driver.findElement(By.xpath("//*[@id=\"redirect\"]//span[text()=\"Logout\"]")).click();
         	   
    	   		
       }
       
       @Then("^user is logged out and SignIn page is loaded$")
  	 public void validateuserloggedout() {
  		   
  		   if (base.driver.findElement(By.xpath("//*[@class='login-page']")).isDisplayed()) {
  				System.out.println("Passed, User Logged out");   
  				   }
  				   else {
  			    System.out.println("Failed, User does not log out");
  				   }
  	   }

       @Then ("^validate necessary fields on HomePage$")
       public void validate_and_highlight_required_fields() throws Throwable {
    	   WebElement ele7 = base.driver.findElement(By.xpath("/html/body/app-root/div/uitk-header/header/img"));
    	   WebElement ele6 = base.driver.findElement(By.xpath("//*[@id=\"redirect\"]//span[text()=\"Logout\"]"));
    	   WebElement ele1 = base.driver.findElement(By.xpath("//*[@id=\"home\"]"));
    	   WebElement ele2 = base.driver.findElement(By.xpath("//*[@id=\"metrics\"]"));
    	   WebElement ele3 = base.driver.findElement(By.xpath("//*[@id=\"drug\"]"));
    	   WebElement ele4 = base.driver.findElement(By.xpath("//*[@id=\"search\"]"));
    	   WebElement ele5 = base.driver.findElement(By.xpath("//*[@id=\"config\"]"));
    	  
    		 if ( base.driver.findElement(By.xpath("/html/body/app-root/div/uitk-header/header/img")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele7);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele7);
    			    System.out.println("Optum Image is present");	
    			   }	else {
    				   System.out.println("Optum Image is not present");
    			   }
    		Thread.sleep(1000);	   	   
    	     if ( base.driver.findElement(By.xpath("//*[@id=\"home\"]")).isDisplayed()) {
        ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele1);
        Thread.sleep(1000);
        ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele1);
        System.out.println("Home Field is present");	
       }	else {
    	   System.out.println("Home Field is not present");
       }
    	     Thread.sleep(1000);	   
    		 if ( base.driver.findElement(By.xpath("//*[@id=\"redirect\"]//span[text()=\"Logout\"]")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele6);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele6);
    			    System.out.println("Logout field is present");	
    			   }	else {
    				   System.out.println("Logout field is not present");
    			   }
    		 Thread.sleep(1000);	  
    		 
    		 if ( base.driver.findElement(By.xpath("//*[@id=\"metrics\"]")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele2);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele2);
    			    System.out.println("Metric field is present");	
    			   }	else {
    				   System.out.println("Metric field is not present");
    			   }
    		 Thread.sleep(1000);	  
    		 
    		 if ( base.driver.findElement(By.xpath("//*[@id=\"drug\"]")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele3);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele3);
    			    System.out.println("Drug Price Search field is present");	
    			   }	else {
    				   System.out.println("Drug Price Search field is not present");
    			   }
    		 Thread.sleep(1000);	  
    		 
    		 if ( base.driver.findElement(By.xpath("//*[@id=\"search\"]")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele4);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele4);
    			    System.out.println("Search field is present");	
    			   }	else {
    				   System.out.println("Search field is not present");
    			   }
    		 Thread.sleep(1000);	  
    		 
    		 if ( base.driver.findElement(By.xpath("//*[@id=\"config\"]")).isDisplayed()) {
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border='6px solid red'", ele5);
    			    Thread.sleep(1000);
    			    ((JavascriptExecutor) base.driver).executeScript("arguments[0].style.border=''", ele5);
    			    System.out.println("Configuration field is present");	
    			   }	else {
    				   System.out.println("Configuration field is not present");
    			   }
    		 Thread.sleep(1000);	  
    		 
    		 
       }
     
    
    }
