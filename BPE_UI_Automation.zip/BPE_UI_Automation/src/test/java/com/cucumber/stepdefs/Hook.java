package com.cucumber.stepdefs;

import com.cucumber.base.BaseUtils;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Hook extends BaseUtils {

    private BaseUtils base;

    public Hook(BaseUtils base){
        this.base = base;
    }

    @Before
    public void initializeTest(){
        System.out.println("I'm Hook to initialize");
        System.setProperty("webdriver.chrome.driver", "src/test/resources/drivers/chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
//        options.addArguments("disable-popup-blocking");
//        options.addArguments("test-type");
//        options.addArguments("start-maximized");

        base.driver = new ChromeDriver();

    }

    @After
    public void tearDownTest(){
        base.driver.close();
        base.driver.quit();
    }
}
